This Install Pack contains the Systemback Debian installation packages.
These packages are compatible with the following Linux distributions:
 - Ubuntu 14.04.X LTS (Trusty Tahr)
 - Ubuntu 15.04 (Vivid Vervet)
 - Ubuntu 15.10 (Wily Werewolf)
 - Ubuntu 16.04.X LTS (Xenial Xerus)
 - Debian 8.0 (Jessie)

To install the program just run the 'install.sh' installer script with root privileges in terminal, like this:

 sudo ./install.sh

or

 sudo sh install.sh

If you want to install the program with debug packages, just run the 'install.sh' installer script with '-d' option:

 sudo ./install.sh -d

or

 sudo sh install.sh -d

If the installation is successful, the following message appears:

 Systemback installation is successful.

If the installation is failed, you will receive the following error message:

 Systemback installation is failed!
