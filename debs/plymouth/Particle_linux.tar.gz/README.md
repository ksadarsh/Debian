The best resolution should be 1280x1024 to be installed in grub (my screen 1920x1080)
you could have to install some font just go to the following adress :
https://forum.ubuntu-fr.org/viewtopic.php?id=1940901
after setting the grub theme range the additional background in :/boot/grub
