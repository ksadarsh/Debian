# plymouth-theme-bgrt-liquid
A Plymouth theme based on BGRT &amp; Spinner themes featuring "liquid" Android bootanimation
